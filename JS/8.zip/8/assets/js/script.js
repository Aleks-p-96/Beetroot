'use strict'

// 3. Створити HTML-сторінку з блоком тексту в рамці. Реалізувати можливість змінювати розмір блоку, якщо затиснути мишку в правому нижньому кутку і тягнути її далі.

let resBtn = document.getElementById('resizer-button');
let resizer = document.getElementById('resizer')

resBtn.addEventListener('mousedown', startResize);

let X,
    Y,
    startWidth,
    startHeight;

function startResize (event) {
    event.preventDefault();
    X = event.clientX;
    Y = event.clientY;
    startWidth = resizer.offsetWidth;
    startHeight = resizer.offsetHeight;
    window.addEventListener('mousemove', resizing);
    window.addEventListener('mouseup', stopResize);
}

function resizing (event) {
    let changeX = event.clientX - X;
    let changeY = event.clientY - Y;
    resizer.style.width = `${startWidth + changeX}px`;
    resizer.style.height = `${startHeight + changeY}px`;
}

function stopResize () {
    window.removeEventListener('mousemove', resizing);
}